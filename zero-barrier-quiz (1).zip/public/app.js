(() => {
  const $ = id => document.getElementById(id);
  const socket = io({transports:["websocket","polling"], upgrade:true});
  let view="join", hostPassword="", pin="", token="", answered=false, currentQuestion=-1, lastState=null;
  const show = id => $(id).classList.remove("hidden");
  const hide = id => $(id).classList.add("hidden");
  function setView(next) {
    view=next; ["joinView","hostView","playerView"].forEach(hide);
    show(next==="join"?"joinView":next==="host"?"hostView":"playerView");
  }
  $("hostLink").onclick=()=>setView("host");
  $("joinForm").onsubmit=e=>{
    e.preventDefault(); pin=$("pin").value.replace(/\D/g,""); const name=$("nickname").value.trim();
    $("joinError").textContent="";
    if(pin.length!==6){$("joinError").textContent="Enter all 6 digits.";return;}
    socket.emit("player:join",{pin,name,token},res=>{
      if(!res.ok){$("joinError").textContent=res.error;return;}
      token=res.token; try{sessionStorage.setItem("zbq-token",token);sessionStorage.setItem("zbq-pin",pin);sessionStorage.setItem("zbq-name",name)}catch{}
      setView("player"); $("playerTitle").textContent="You're in, "+name+"!";
      renderState(res.state);
    });
  };
  try {
    const savedPin=sessionStorage.getItem("zbq-pin"), savedToken=sessionStorage.getItem("zbq-token"), savedName=sessionStorage.getItem("zbq-name");
    if(savedPin&&savedToken&&savedName){$("pin").value=savedPin;$("nickname").value=savedName;token=savedToken;}
  } catch {}
  $("createRoom").onclick=()=>{
    hostPassword=$("hostPassword").value;
    $("hostError").textContent="";
    socket.emit("host:create",{password:hostPassword},res=>{
      if(!res.ok){$("hostError").textContent=res.error;return;}
      pin=res.pin; show("hostGame");hide("hostLogin");$("hostPin").textContent=pin; $("startQuiz").disabled=false;
    });
  };
  $("copyPin").onclick=()=>navigator.clipboard?.writeText(pin);
  $("startQuiz").onclick=()=>socket.emit("host:start",{},res=>{if(!res.ok)$("hostError").textContent=res.error;});
  $("nextQuestion").onclick=()=>socket.emit("host:next",{},res=>{if(!res.ok)$("hostError").textContent=res.error;});
  $("closeRoom").onclick=()=>{if(confirm("End this quiz for everyone?"))socket.emit("host:close",{},()=>{location.reload();});};
  function renderState(state){
    if(!state)return; lastState=state;
    if(view==="host"){
      $("playerCount").textContent=state.count;
      $("hostProgress").textContent=state.status==="lobby"?"Lobby":state.status==="finished"?"Finished":`${state.questionIndex+1} / ${state.total}`;
      $("startQuiz").classList.toggle("hidden",state.status!=="lobby");
      $("nextQuestion").classList.toggle("hidden",state.status!=="question");
      $("nextQuestion").textContent=state.questionIndex===state.total-1?"Show final results":"Next question";
      $("hostQuestion").textContent=state.question?`Level ${state.question.level} · ${state.question.topic}\n${state.question.question}`:state.status==="finished"?"Quiz complete!":"Waiting for participants. Start when ready.";
      $("leaderboard").innerHTML="";
      state.scores.slice(0,20).forEach(p=>{const li=document.createElement("li");li.textContent=`${p.name} — ${p.score} pts (${p.correct} correct)`;$("leaderboard").appendChild(li);});
    }
    if(view==="player"){
      $("correctCount").textContent=(state.scores.find(p=>p.name===$("nickname").value.trim())||{}).correct||0;
      const q=state.question;
      if(state.status==="lobby"){hide("questionArea");$("playerTitle").textContent="You're in!";$("playerMessage").textContent="Waiting for the host to start…";}
      else if(state.status==="finished"){hide("questionArea");$("playerTitle").textContent="Quiz complete!";$("playerMessage").textContent=`You answered ${$("correctCount").textContent} of 15 correctly. Percentage: ${Math.round(Number($("correctCount").textContent)/15*100)}%.`; }
      else if(q && q.index!==currentQuestion){renderQuestion(q);}
      $("progress").textContent=state.status==="question"?`Question ${state.questionIndex+1} of ${state.total}`:"";
    }
  }
  function renderQuestion(q){
    currentQuestion=q.index;answered=false;show("questionArea");$("playerTitle").textContent=`Level ${q.level}`;
    $("playerMessage").textContent="Choose one answer. Feedback appears immediately.";
    $("levelTag").textContent=`LEVEL ${q.level} · ${["","EASY","MODERATE","HARD"][q.level]}`;
    $("topic").textContent=q.topic;$("questionText").textContent=q.question;$("feedback").textContent="";$("feedback").className="feedback";
    $("options").innerHTML="";
    q.options.forEach((label,index)=>{
      const b=document.createElement("button");b.className="option";b.innerHTML=`<span class="circle"></span><span></span>`;
      b.querySelector("span:last-child").textContent=label;
      b.onclick=()=>{
        if(answered)return;answered=true;
        [...$("options").children].forEach(x=>x.disabled=true);b.classList.add("selected");
        socket.emit("player:answer",{choice:index},res=>{if(!res.ok)$("feedback").textContent=res.error;});
      };
      $("options").appendChild(b);
    });
  }
  socket.on("answer:result",res=>{
    $("feedback").textContent=res.correct?"✓ Correct!":"✕ Incorrect";
    $("feedback").className="feedback "+(res.correct?"good":"bad");
    const buttons=[...$("options").children]; if(buttons[res.correctOption])buttons[res.correctOption].classList.add("correct");
    const picked=buttons.find(b=>b.classList.contains("selected"));if(picked&&!res.correct)picked.classList.add("wrong");
    $("scoreCount").textContent=res.score;
  });
  socket.on("room:update",state=>{if(view==="host"&&state.pin===pin)renderState(state);if(view==="player"&&state.pin===pin)renderState(state);});
  socket.on("quiz:event",event=>{if(event.action==="SHOW_INPUTS"){$("playerMessage").textContent="Question is live · "+event.time+" seconds";}});
  socket.on("room:closed",()=>{if(view==="player"){$("playerTitle").textContent="This game has ended";$("playerMessage").textContent="Ask your host for a new PIN.";hide("questionArea");}});
  socket.on("connect",()=>{
    if(view==="player"&&pin&&token)socket.emit("player:join",{pin,name:$("nickname").value.trim(),token},res=>{if(res.ok){token=res.token;renderState(res.state);}});
  });
  socket.on("disconnect",()=>{if(view==="player")$("playerMessage").textContent="Connection interrupted. Reconnecting…";});
  // If a host refreshes, resume a room by entering the PIN and host password.
  const resume=document.createElement("div");resume.className="resume";
  resume.innerHTML='<label for="resumePin">Resume existing host room (optional)</label><input id="resumePin" inputmode="numeric" maxlength="6" placeholder="6-digit PIN"><button id="resumeHost" class="quiet">Resume room</button>';
  $("hostLogin").appendChild(resume);
  $("resumeHost").onclick=()=>{
    hostPassword=$("hostPassword").value;
    socket.emit("host:resume",{pin:$("resumePin").value,password:hostPassword},res=>{
      if(!res.ok){$("hostError").textContent=res.error;return;}
      pin=$("resumePin").value;show("hostGame");hide("hostLogin");$("hostPin").textContent=pin;renderState(res.state);
    });
  };
})();