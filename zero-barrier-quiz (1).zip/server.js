const express = require("express");
const http = require("http");
const crypto = require("crypto");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  serveClient: true,
  cors: { origin: false },
  perMessageDeflate: false
});
const PORT = process.env.PORT || 3000;
const HOST_PASSWORD = process.env.HOST_PASSWORD || "change-this-before-deploying";
app.use(express.static(path.join(__dirname, "public"), { maxAge: "1h" }));
app.get("/health", (_req, res) => res.json({ ok: true }));

// The question set is deliberately text-only and small. All players see the same
// active question; question order is shuffled within each level for each room.
const BANK = [
  {level:1, topic:"Chemistry", q:"What is the chemical formula of water?", o:["H₂O","CO₂","O₂","NaCl"], a:0},
  {level:1, topic:"Physics", q:"What force pulls objects toward Earth?", o:["Magnetism","Gravity","Friction","Electricity"], a:1},
  {level:1, topic:"Chemistry", q:"Which gas do humans need for respiration?", o:["Nitrogen","Hydrogen","Oxygen","Helium"], a:2},
  {level:1, topic:"Physics", q:"What is the SI unit of force?", o:["Joule","Watt","Newton","Pascal"], a:2},
  {level:1, topic:"Chemistry", q:"A substance with a pH below 7 is generally…", o:["Acidic","Neutral","Basic","Metallic"], a:0},
  {level:1, topic:"Physics", q:"Which object is a good conductor of electricity?", o:["Rubber band","Copper wire","Dry wood","Plastic ruler"], a:1},
  {level:1, topic:"Chemistry", q:"Which state of matter has a fixed volume but no fixed shape?", o:["Solid","Liquid","Gas","Plasma"], a:1},
  {level:1, topic:"Physics", q:"Which energy source comes from the Sun?", o:["Solar energy","Tidal energy","Geothermal energy","Nuclear fuel"], a:0},
  {level:1, topic:"Chemistry", q:"What is the common name for sodium chloride?", o:["Baking soda","Sugar","Table salt","Vinegar"], a:2},
  {level:1, topic:"Physics", q:"Sound travels fastest through which of these?", o:["Vacuum","Air","Water","Steel"], a:3},
  {level:2, topic:"General Knowledge", q:"What is the capital of Japan?", o:["Seoul","Tokyo","Beijing","Bangkok"], a:1},
  {level:2, topic:"General Knowledge", q:"How many sides does a hexagon have?", o:["Five","Six","Seven","Eight"], a:1},
  {level:2, topic:"General Knowledge", q:"Which is the largest ocean on Earth?", o:["Atlantic","Indian","Arctic","Pacific"], a:3},
  {level:2, topic:"General Knowledge", q:"The currency of the United Kingdom is the…", o:["Euro","Pound sterling","Dollar","Franc"], a:1},
  {level:2, topic:"General Knowledge", q:"Which planet is known as the Red Planet?", o:["Venus","Mars","Jupiter","Mercury"], a:1},
  {level:2, topic:"General Knowledge", q:"How many minutes are in two hours?", o:["100","110","120","_pixels"], a:2},
  {level:2, topic:"General Knowledge", q:"Which is the smallest prime number?", o:["0","1","2","3"], a:2},
  {level:2, topic:"General Knowledge", q:"Which language is primarily spoken in Brazil?", o:["Spanish","Portuguese","French","Italian"], a:1},
  {level:2, topic:"General Knowledge", q:"What is the name of the world's largest hot desert?", o:["Gobi","Sahara","Kalahari","Arabian"], a:1},
  {level:2, topic:"General Knowledge", q:"Which instrument measures temperature?", o:["Barometer","Thermometer","Anemometer","Hygrometer"], a:1},
  {level:3, topic:"Nature", q:"What is the process by which plants lose water vapour through leaves?", o:["Respiration","Transpiration","Pollination","Germination"], a:1},
  {level:3, topic:"Science", q:"Which part of a cell contains most of its genetic material?", o:["Nucleus","Ribosome","Cell membrane","Vacuole"], a:0},
  {level:3, topic:"Technology", q:"What does the “S” in HTTPS indicate?", o:["Simple","Secure","System","Shared"], a:1},
  {level:3, topic:"Science", q:"Which particles have a negative electric charge?", o:["Protons","Neutrons","Electrons","Photons"], a:2},
  {level:3, topic:"Technology", q:"Which is commonly used to style web pages?", o:["HTML","CSS","SQL","HTTP"], a:1},
  {level:3, topic:"Nature", q:"What is the main gas in Earth's atmosphere?", o:["Oxygen","Carbon dioxide","Nitrogen","Argon"], a:2},
  {level:3, topic:"Science", q:"What is the approximate speed of light in a vacuum?", o:["300,000 km/s","30,000 km/s","3,000 km/s","300 km/s"], a:0},
  {level:3, topic:"Technology", q:"Which number system do computers fundamentally use?", o:["Decimal","Binary","Roman","Hexadecimal only"], a:1},
  {level:3, topic:"Nature", q:"Which biome is characterized by permafrost and very low temperatures?", o:["Savanna","Tundra","Tropical rainforest","Chaparral"], a:1},
  {level:3, topic:"Science", q:"Which molecule carries genetic instructions in most living organisms?", o:["DNA","Starch","Glucose","Cellulose"], a:0}
];
// Fix a typo defensively in the authored bank.
BANK.find(q => q.q.startsWith("How many minutes")) .o[3] = "140";

const rooms = new Map();
const players = new Map(); // socket.id -> {pin, token}
const now = () => Date.now();
const shuffle = arr => {
  const a = arr.slice();
  for (let i=a.length-1;i>0;i--) { const j=crypto.randomInt(i+1); [a[i],a[j]]=[a[j],a[i]]; }
  return a;
};
const publicQuestion = (q, index, total) => ({
  index, total, level:q.level, topic:q.topic, question:q.q,
  options:q.o, time:20
});
function roomSnapshot(room) {
  return { pin:room.pin, status:room.status, count:room.players.size,
    questionIndex:room.index, total:room.questions.length,
    question: room.status === "question" ? publicQuestion(room.questions[room.index], room.index, room.questions.length) : null,
    scores: [...room.players.values()].map(p => ({name:p.name, score:p.score, correct:p.correct, answered:!!p.answers[room.index]}))
      .sort((a,b)=>b.score-a.score) };
}
function broadcastRoom(room) { io.to(room.pin).emit("room:update", roomSnapshot(room)); }
function makePin() {
  let pin;
  do { pin = String(crypto.randomInt(100000, 1000000)); } while (rooms.has(pin));
  return pin;
}
function makeRoom() {
  const pin = makePin();
  const questions = [1,2,3].flatMap(level => shuffle(BANK.filter(q=>q.level===level)).slice(0,5));
  const room = { pin, questions, players:new Map(), status:"lobby", index:-1, createdAt:now(), hostSocket:null, timer:null };
  rooms.set(pin, room);
  return room;
}
function cleanRoom(room) {
  clearTimeout(room.timer);
  io.to(room.pin).emit("room:closed");
  rooms.delete(room.pin);
  for (const [id,p] of players) if (p.pin===room.pin) players.delete(id);
}
function safeRoom(pin) { return rooms.get(String(pin||"").replace(/\D/g,"").slice(0,6)); }

io.on("connection", socket => {
  socket.on("host:create", ({password}={}, cb=()=>{}) => {
    if (password !== HOST_PASSWORD) return cb({ok:false,error:"Incorrect host password."});
    const room = makeRoom();
    room.hostSocket = socket.id;
    socket.join(room.pin);
    socket.data.hostPin = room.pin;
    cb({ok:true,pin:room.pin});
    broadcastRoom(room);
  });
  socket.on("host:resume", ({pin,password}={}, cb=()=>{}) => {
    const room=safeRoom(pin);
    if(password!==HOST_PASSWORD || !room) return cb({ok:false,error:"Host access or room not found."});
    room.hostSocket=socket.id; socket.join(room.pin); socket.data.hostPin=room.pin;
    cb({ok:true,state:roomSnapshot(room)}); broadcastRoom(room);
  });
  socket.on("host:start", (_data, cb=()=>{}) => {
    const room=rooms.get(socket.data.hostPin);
    if(!room || room.hostSocket!==socket.id) return cb({ok:false,error:"Host only."});
    if(room.status!=="lobby") return cb({ok:false,error:"Quiz already started."});
    room.status="question"; room.index=0;
    io.to(room.pin).emit("quiz:event",{action:"SHOW_INPUTS",time:20});
    broadcastRoom(room); cb({ok:true});
  });
  socket.on("host:next", (_data, cb=()=>{}) => {
    const room=rooms.get(socket.data.hostPin);
    if(!room || room.hostSocket!==socket.id) return cb({ok:false,error:"Host only."});
    if(room.index+1>=room.questions.length) {
      room.status="finished"; broadcastRoom(room);
      io.to(room.pin).emit("quiz:finished",roomSnapshot(room)); return cb({ok:true,finished:true});
    }
    room.index++; room.status="question";
    io.to(room.pin).emit("quiz:event",{action:"SHOW_INPUTS",time:20});
    broadcastRoom(room); cb({ok:true});
  });
  socket.on("host:close", (_data, cb=()=>{}) => {
    const room=rooms.get(socket.data.hostPin);
    if(!room || room.hostSocket!==socket.id) return cb({ok:false,error:"Host only."});
    cleanRoom(room); cb({ok:true});
  });
  socket.on("player:join", ({pin,name,token}={}, cb=()=>{}) => {
    const room=safeRoom(pin);
    name=String(name||"").trim().slice(0,24);
    if(!room) return cb({ok:false,error:"That PIN was not found. Check it and try again."});
    if(!name) return cb({ok:false,error:"Enter a nickname."});
    if(room.status==="finished") return cb({ok:false,error:"This quiz has ended."});
    let player = token && [...room.players.values()].find(p=>p.token===token);
    if(player) {
      for(const [id,p] of room.players) if(p===player) { room.players.delete(id); players.delete(id); }
    } else {
      if(room.players.size>=500) return cb({ok:false,error:"This room is full."});
      player={token:crypto.randomBytes(18).toString("hex"),name,score:0,correct:0,answers:{}};
    }
    player.name=name;
    room.players.set(socket.id,player); players.set(socket.id,{pin:room.pin,token:player.token});
    socket.join(room.pin);
    cb({ok:true,token:player.token,state:roomSnapshot(room)});
    if(room.status==="question") socket.emit("quiz:event",{action:"SHOW_INPUTS",time:20});
    broadcastRoom(room);
  });
  socket.on("player:answer", ({choice}={}, cb=()=>{}) => {
    const meta=players.get(socket.id), room=meta&&rooms.get(meta.pin), player=room&&room.players.get(socket.id);
    if(!room || !player || room.status!=="question") return cb({ok:false,error:"No active question."});
    if(player.answers[room.index]!==undefined) return cb({ok:false,error:"Answer already submitted."});
    const q=room.questions[room.index];
    const valid=Number.isInteger(choice)&&choice>=0&&choice<4;
    if(!valid) return cb({ok:false,error:"Invalid answer."});
    const correct=choice===q.a;
    player.answers[room.index]={choice,correct};
    if(correct) { player.correct++; player.score+=100; }
    socket.emit("answer:result",{correct,correctOption:q.a,score:player.score});
    cb({ok:true,correct});
    broadcastRoom(room);
  });
  socket.on("disconnect", () => {
    const meta=players.get(socket.id);
    if(meta) {
      const room=rooms.get(meta.pin);
      if(room) { const p=room.players.get(socket.id); room.players.delete(socket.id); if(p) room.disconnected.set?.(p.token,p); broadcastRoom(room); }
      players.delete(socket.id);
    }
    const pin=socket.data.hostPin, room=rooms.get(pin);
    if(room && room.hostSocket===socket.id) room.hostSocket=null;
  });
});

// Keep reconnectable players for 10 minutes, then remove inactive rooms after 2 hours.
const sweep=setInterval(()=>{
  for(const room of rooms.values()) {
    if(now()-room.createdAt>2*60*60*1000) cleanRoom(room);
  }
}, 60_000);
sweep.unref();

server.listen(PORT, "0.0.0.0", () => console.log(`Zero Barrier Quiz running on port ${PORT}`));
